<?php include_once('header.php'); ?>

<section>
	<h1>View</h1>
	<?php
	get_the_files('Web Server');
	?>
</section>

<?php include_once('footer.php'); ?>
