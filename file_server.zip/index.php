<?php include_once('header.php'); ?>

<section>
	<h1>View</h1>
	<ul>
		<li><a href="router.php">Router</a> <br> <a href="#">refresh</a></li>
		<li><a href="file_server.php">File Server</a> <br> <a href="#">refresh</a></li>
		<li><a href="web_server.php">Web Server</a> <br> <a href="#">refresh</a></li>
		<li><a href="snmp_manager.php">SNMP Manager</a> <br> <a href="#">refresh</a></li>
		<li><a href="devices.php">Agent PC and Laptop</a> <br> <a href="#">refresh</a></li>
	</ul>
</section>

<?php include_once('footer.php'); ?>
